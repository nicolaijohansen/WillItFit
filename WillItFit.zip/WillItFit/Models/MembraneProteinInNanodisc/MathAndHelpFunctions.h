double complex **ComplexArray(Dimension1, Dimension2)
{
	int i; 
	int j;
	double complex ** Array;

	Array = (double complex**) malloc(Dimension1 * sizeof(double complex*));

	for (i = 0; i < Dimension1; i++)
	{
		Array[i] = (double complex*) malloc(Dimension2 * sizeof(double complex));

		for (j = 0; j < Dimension2; j++)
		{
			Array[i][j] = 0.0;
		}
	}

	return Array;
}

void FreeComplexArray(double complex **Array, int Dimension1, int Dimension2)
{
	int i;

	for(i = 0; i < Dimension1; i++)
	{
		free(Array[i]);
	}

	free(Array);
}

void CopyResidue(struct Residue * Original, struct Residue * Copy)
{
	Copy->xVolume = Original->xVolume;
	Copy->yVolume = Original->yVolume;
	Copy->zVolume = Original->zVolume;

	Copy->xXRayScattering = Original->xXRayScattering;
	Copy->yXRayScattering = Original->yXRayScattering;
	Copy->zXRayScattering = Original->zXRayScattering;

	Copy->xNeutronScattering = Original->xNeutronScattering;
	Copy->yNeutronScattering = Original->yNeutronScattering;
	Copy->zNeutronScattering = Original->zNeutronScattering;

	Copy->XRayScatteringLength	= Original->XRayScatteringLength;
	Copy->NeutronScatteringLength = Original->NeutronScatteringLength;

	Copy->Volume = Original->Volume;
	Copy->Name[0] = Original->Name[0];
	Copy->Name[1] = Original->Name[1];
	Copy->Name[2] = Original->Name[2];
	Copy->ResidueID = Original->ResidueID;
}

int Sign(double x) {
	int Result;

	if (x < 0.0) {
		Result = -1;
	} else if (x > 0.0) {
		Result = 1;
	} else {
		Result = 0;
	}

	return Result;
}

double complex PolarComplexNumber(double Radius, double Phi)
{
	if (Phi == 0)
		return Radius + I * 0.0;
	else
		return Radius * (cos(Phi) + I * sin(Phi));
}

void AddScatteringFromResidue(double complex **Beta, double q, struct Residue CurrentResidue, double Contrast, double ScatteringLengthDensityOfSolvent)
{
	// Søren Kynde, 2012 (rewritten by Martin Cramer Pedersen, 2015)
	// This function adds the scattering of a residue to the scattering amplitude expandended by the spherical harmonic coefficients Beta_lm.
	int l;
	int m;
	
	double x;
	double y;
	double z;

	double Radius;
	double Theta;
	double Phi;
	
	double ScatteringLengthOfResidue; 
	double ScatteringLengthOfDisplacedSolvent = CurrentResidue.Volume * ScatteringLengthDensityOfSolvent;
	double ExcessScatteringLength;

	if (Contrast < 0.0)
	{
		ScatteringLengthOfResidue = CurrentResidue.XRayScatteringLength;
		ExcessScatteringLength = ScatteringLengthOfResidue - ScatteringLengthOfDisplacedSolvent;

		x = (CurrentResidue.xXRayScattering * ScatteringLengthOfResidue - CurrentResidue.xVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
		y = (CurrentResidue.yXRayScattering * ScatteringLengthOfResidue - CurrentResidue.yVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
		z = (CurrentResidue.zXRayScattering * ScatteringLengthOfResidue - CurrentResidue.zVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
	} else {
		ScatteringLengthOfResidue = CurrentResidue.NeutronScatteringLength;
		ExcessScatteringLength	= ScatteringLengthOfResidue - ScatteringLengthOfDisplacedSolvent;

		x = (CurrentResidue.xNeutronScattering * ScatteringLengthOfResidue - CurrentResidue.xVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
		y = (CurrentResidue.yNeutronScattering * ScatteringLengthOfResidue - CurrentResidue.yVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
		z = (CurrentResidue.zNeutronScattering * ScatteringLengthOfResidue - CurrentResidue.zVolume * ScatteringLengthOfDisplacedSolvent) / ExcessScatteringLength;
	}

	Radius = sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
	Theta = acos(z / Radius);
	Phi = acos(x / (Radius * sin(Theta))) * Sign(y);




	/*****************/
	/* old GSL usage */
	/*****************/

	/*

	double Legendre[NumberOfHarmonics + 1] ;
	double Bessel[NumberOfHarmonics + 1] ;

	// Calculate spherical Bessel functions for l = 0 to NumberOfHarmonics
	gsl_sf_bessel_jl_array( NumberOfHarmonics, q * Radius, Bessel) ;

	// Calculate all associated Legendre polynomials $P_l^m(cos(Theta))$ of degree l = m ... NumberOfHarmonics including prefactor $\sqrt{(2l+1)/(4\pi)} \sqrt{(l-m)!/(l+m)!}$ - store the values in Legendre[m], Legendre[m + 1], ..., Legendre[NumberOfHarmonics]
	for ( m = 0; m < NumberOfHarmonics + 1; m++)
	{
		// http://home.thep.lu.se/~jari/documents/gsl-ref.html/Associated-Legendre-Polynomials-and-Spherical-Harmonics.html
		// int gsl_sf_legendre_sphPlm_array (int lmax, int m, double x, double result_array[]):
		// These functions compute an array of spherical harmonic associated Legendre polynomials $\sqrt{(2l+1)/(4\pi)} \sqrt{(l-m)!/(l+m)!} P_l^m(x)$, and optionally their derivatives, for m >= 0, l = |m|, ..., lmax, |x| <= 1.0
		// i.e. they provide the unnormalized associated Legendre polynomials P_l^m(x) times the prefactor \sqrt{(2l+1)/(4\pi)} \sqrt{(l-m)!/(l+m)!} P_l^m( cos(theta) ) for m >= 0 and l = m ... NumberOfHarmonics
		// will fill Legendre[m,...,NumberOfHarmonics] starting from &Legendre[m]
		gsl_sf_legendre_sphPlm_array( NumberOfHarmonics, m, cos(Theta), &Legendre[m]) ;

		for ( l = m; l < NumberOfHarmonics + 1; l++)
		{
			Beta[l][m] += sqrt(4.0 * M_PI) * cpow(I, l) * ExcessScatteringLength * Bessel[l] * Legendre[l] * PolarComplexNumber(1.0, -m * Phi) ;
		}
	}

	*/





	/*****************/
	/* new GSL usage */
	/*****************/

	// https://www.gnu.org/software/gsl/doc/html/specfunc.html?highlight=gsl_sf_bessel_jl_array#associated-legendre-polynomials-and-spherical-harmonics

	/*
	size_t gsl_sf_legendre_array_n(const size_t lmax)
	This function returns the minimum array size for maximum degree lmax, needed for the array versions of the associated Legendre functions. 
	The size is calculated as the total number of P_l^m(x) functions, plus extra space for precomputing multiplicative factors used in the recurrence relations.
	*/
	size_t LegendreSize = gsl_sf_legendre_array_n( NumberOfHarmonics ) ;
	double Legendre[LegendreSize] ;
	double Bessel[NumberOfHarmonics + 1] ;
	//printf("LegendreSize=%d\n", LegendreSize) ;


	// Calculate spherical Bessel functions for l = 0 to NumberOfHarmonics
	/*
	Same as for old GSL usage
	int gsl_sf_bessel_jl_array(int lmax, double x, double result_array[])
	This routine computes the values of the regular spherical Bessel functions j_l(x) for l from 0 to lmax inclusive for lmax >= 0 and x >= 0, storing the results in the array result_array.
	*/
	gsl_sf_bessel_jl_array( NumberOfHarmonics, q * Radius, Bessel) ;

	// Calculate all associated Legendre polynomials $P_l^m(cos(Theta))$ of degree l = m ... NumberOfHarmonics including prefactor $\sqrt{(2l+1)/(4\pi)} \sqrt{(l-m)!/(l+m)!}$
	/*

	int gsl_sf_legendre_array(const gsl_sf_legendre_t norm, const size_t lmax, const double x, double result_array[])
	These functions calculate all normalized associated Legendre polynomials for 0 <= l <= lmax and 0 <= m <= l for |x| <= 1.
	The norm parameter specifies which normalization is used.
	The normalized P_l^m(x) values are stored in result_array, whose minimum size can be obtained from calling gsl_sf_legendre_array_n().
	The array index of P_l^m(x) is obtained by calling gsl_sf_legendre_array_index(l, m).
	To include or exclude the Condon-Shortley phase factor of (-1)^m, set the parameter csphase to either -1 or 1 respectively in the _e function.
	This factor is included by default.

	gsl_sf_legendre_t:
		Value				Description
		GSL_SF_LEGENDRE_NONE		The unnormalized associated Legendre polynomials P_l^m(x)
		GSL_SF_LEGENDRE_SCHMIDT		The Schmidt semi-normalized associated Legendre polynomials S_l^m(x)
	--->	GSL_SF_LEGENDRE_SPHARM		The spherical harmonic associated Legendre polynomials Y_l^m(x) 	<---
		GSL_SF_LEGENDRE_FULL		The fully normalized associated Legendre polynomials N_l^m(x)
	*/
	const gsl_sf_legendre_t LegendreNorm = GSL_SF_LEGENDRE_SPHARM ; // provides $\sqrt{(2l+1)/(4\pi)} \sqrt{(l-m)!/(l+m)!} P_l^m(x)$ if the Condon-Shortley phase factor (-1)^m is omitted by using csphase = 1.0
	const double csphase = 1.0 ;

	gsl_sf_legendre_array_e( LegendreNorm, NumberOfHarmonics, cos(Theta), csphase, Legendre) ;

	size_t LegendreIndex ;
	for ( m = 0; m < NumberOfHarmonics + 1; m++)
	{
		for ( l = m; l < NumberOfHarmonics + 1; l++)
		{
			/*
			size_t gsl_sf_legendre_array_index(const size_t l, const size_t m)
			This function returns the index into result_array, result_deriv_array, or result_deriv2_array corresponding to P_l^m(x), P_l^{'m}(x), or P_l^{''m}(x).
			The index is given by l(l+1)/2 + m.
			*/
			LegendreIndex = gsl_sf_legendre_array_index( l, m) ;

			Beta[l][m] += sqrt(4.0 * M_PI) * cpow(I, l) * ExcessScatteringLength * Bessel[l] * Legendre[LegendreIndex] * PolarComplexNumber(1.0, -m * Phi) ;
		}
	}

}

