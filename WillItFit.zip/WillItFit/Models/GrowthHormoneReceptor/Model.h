double Model(double q, double * Parameters, double * Constraints, double Contrast, struct Protein ProteinStructure, struct UserDefined * UserDefinedStructure)
{

    // Get scattering length densities
    double ScatteringLengthDensityOfCaps   = Constraints[0];
    double ScatteringLengthDensityOfCore   = Constraints[1];
    double ScatteringLengthDensityOfMethyl = Constraints[2];
    double ScatteringLengthDensityOfBelt   = Constraints[3];
    double ScatteringLengthDensityOfWater  = Constraints[4];
    double ScatteringLengthDensityOfCoil   = Constraints[5];
  
    // Get the parameters describing the geometry of the disc
    double HeightOfBelt        = Parameters[2];
    double HeightOfLipids      = Constraints[6];
    double HeightOfCore        = Constraints[7];
    double HeightOfMethyl      = Constraints[8];
    double MajorSemiAxisOfCore = Constraints[23];
    double MinorSemiAxisOfCore = Constraints[24];
    double ThicknessOfBelt     = Constraints[27];

    // Properties describing ICD
    double RgOfCoil     = Parameters[25];
    double VolumeOfCoil = Constraints[10] ;
    double Displacement = (RgOfCoil + 0.5 * HeightOfLipids); 
    double Debye;



//radius of outer disc = 1.5 x rg
//radius of inner disc = 1 x rg
//
    double OuterDiscDisplacement = (0.5 * HeightOfLipids + 0.75* RgOfCoil);
    double InnerDiscDisplacement = (0.5 * HeightOfLipids +  0.5* RgOfCoil);
    double OuterDiscRadius =  RgOfCoil + 0.5 * RgOfCoil;
    double InnerDiscRadius =  RgOfCoil;
    double OuterDiscHeight =  RgOfCoil + 0.5 * RgOfCoil;
    double InnerDiscHeight =  RgOfCoil; 





    // Get the parameters describng the membrane protein
    double CorrectionToMPVolume = Parameters[9];
    double MPTranslation[3];
    double MPRotation[3][3];
    SetTranslationVector(MPTranslation, Parameters[19], Parameters[20], Parameters[21]);
    SetRotationMatrix(MPRotation, Parameters[22], Parameters[23], Parameters[24]);

    double GFPTranslation[3];
    double GFPRotation[3][3];
    SetTranslationVector(GFPTranslation, 0, 0, 0);  //GFP displacement now contained within hollow disc form factor?
    SetRotationMatrix(GFPRotation, 0, 0, 0);

    Constraints[13] = GFPTranslation[0];
    Constraints[14] = GFPTranslation[1];
    Constraints[15] = GFPTranslation[2];

    // Parameters describing the GFP

    // Parameters describing the solution
    double Roughness;
    double Scaling;
    double Background;
    double Intensity;
    double ConcentrationOfSample = Constraints[21];
   
    int j,l,m;
    struct Residue CurrentResidue;

	// Structures for holding spherical harmonics
    double complex ** Alpha = ComplexArray(Nh + 1, Nh + 1);
    double complex ** Beta  = ComplexArray(Nh + 1, Nh + 1);
    double complex ** Beta2 = ComplexArray(Nh + 1, Nh + 1);
    double complex ** Gamma = ComplexArray(Nh + 1, Nh + 1);
    double complex ** Delta = ComplexArray(Nh + 1, Nh + 1);
    double complex ** Delta2 = ComplexArray(Nh + 1, Nh + 1);


    // Compute the roughness from the parameters
    if (Contrast >= 0.0 && Contrast <= 100.0) {
        Roughness  = exp(-(q * Parameters[16] * q * Parameters[16]));
        Scaling    = Parameters[18] * (Contrast / 100.0 * Parameters[11] + (100.0 - Contrast) / 100.0 * Parameters[13]);
        Background = Contrast / 100.0 * Parameters[10] + (100.0 - Contrast) / 100.0 * Parameters[12];
    } else {
        Roughness  = exp(-(q * Parameters[6] * q * Parameters[6]));
        Scaling    = Parameters[15] * Parameters[18];
        Background = Parameters[14];
    }

    // Nanodisc
    NanodiscPDBModel(Alpha,q, ScatteringLengthDensityOfCaps, ScatteringLengthDensityOfCore, ScatteringLengthDensityOfMethyl,ScatteringLengthDensityOfBelt, ScatteringLengthDensityOfWater, MajorSemiAxisOfCore, MinorSemiAxisOfCore, ThicknessOfBelt, HeightOfLipids, HeightOfCore, HeightOfMethyl, HeightOfBelt);

    // Protein structure for ECD - use corresponding residue numbers from PDB, different position!!
    for (j = 0; j <=289; ++j) {
        CopyResidue(&ProteinStructure.Residues[j], &CurrentResidue);
        Orient(&CurrentResidue.xVolume, &CurrentResidue.yVolume, &CurrentResidue.zVolume, MPRotation, MPTranslation);

        if (Contrast < 0.0 || Contrast > 100.0) {
            Orient(&CurrentResidue.xXRayScattering, &CurrentResidue.yXRayScattering, &CurrentResidue.zXRayScattering, MPRotation, MPTranslation);
        } else {
            Orient(&CurrentResidue.xNeutronScattering, &CurrentResidue.yNeutronScattering, &CurrentResidue.zNeutronScattering, MPRotation, MPTranslation);
        }

       AddScatteringFromResidue(Beta, q, CurrentResidue, Contrast, ScatteringLengthDensityOfCaps, ScatteringLengthDensityOfCore, ScatteringLengthDensityOfMethyl, ScatteringLengthDensityOfBelt, ScatteringLengthDensityOfWater, HeightOfLipids, HeightOfCore, HeightOfMethyl, HeightOfBelt, CorrectionToMPVolume, MajorSemiAxisOfCore, MinorSemiAxisOfCore);
    }

       // Protein structure for GFP
    for (j = 290; j <=510; ++j) {
        CopyResidue(&ProteinStructure.Residues[j], &CurrentResidue);
        Orient(&CurrentResidue.xVolume, &CurrentResidue.yVolume, &CurrentResidue.zVolume, GFPRotation, GFPTranslation);

        if (Contrast < 0.0 || Contrast > 100.0) {
            Orient(&CurrentResidue.xXRayScattering, &CurrentResidue.yXRayScattering, &CurrentResidue.zXRayScattering, GFPRotation, GFPTranslation);
        } else {
            Orient(&CurrentResidue.xNeutronScattering, &CurrentResidue.yNeutronScattering, &CurrentResidue.zNeutronScattering, GFPRotation, GFPTranslation);
        }

       AddScatteringFromResidue2(Beta2, q, CurrentResidue, Contrast, ScatteringLengthDensityOfCaps, ScatteringLengthDensityOfCore, ScatteringLengthDensityOfMethyl, ScatteringLengthDensityOfBelt, ScatteringLengthDensityOfWater, HeightOfLipids, HeightOfCore, HeightOfMethyl, HeightOfBelt, CorrectionToMPVolume, MajorSemiAxisOfCore, MinorSemiAxisOfCore);
    }


    Gausscoil(Gamma, RgOfCoil, ScatteringLengthDensityOfCoil, VolumeOfCoil, ScatteringLengthDensityOfWater, q, Displacement, M_PI, 0);

    Debye = DebyeFunc(RgOfCoil, ScatteringLengthDensityOfCoil, VolumeOfCoil, ScatteringLengthDensityOfWater, q);


    //Create a hollow disc form factor.  1 is the larger disc, 2 is the smaller.  formfactors are subtracted from one enother to create hollow disc.  must be normalised by volume
     HollowDiscflat(Delta, OuterDiscRadius, OuterDiscHeight, OuterDiscDisplacement, InnerDiscRadius, InnerDiscHeight, InnerDiscDisplacement, M_PI, 0, q);


    // Calculate intensity
    Intensity = 0.0;

    for (l = 0; l < Nh + 1; ++l) {
         for (m = 0; m < l + 1; ++m) {

            Delta2[l][m] = Delta[l][m] * Beta2[0][0] ;
             

            Intensity += ((m > 0) + 1) * (pow(cabs(sqrt(Roughness) * Alpha[l][m] + Beta[l][m]  + Delta2[l][m] + Gamma[l][m] ), 2) - pow(cabs(Delta2[l][m]), 2) - pow(cabs(Gamma[l][m]),2) + pow(cabs(Beta2[l][m]),2));
        }
    }

    Intensity = Intensity + Debye;
    // Scale the sum
    Intensity *= ConcentrationOfSample;
    Intensity = Intensity * Scaling + Background;

    // Free the arrays
    FreeComplexArray(Alpha, Nh + 1, Nh + 1);
    FreeComplexArray(Beta, Nh + 1, Nh + 1);
    FreeComplexArray(Beta2, Nh + 1, Nh + 1);
    FreeComplexArray(Delta, Nh + 1, Nh + 1);
    FreeComplexArray(Gamma, Nh + 1, Nh + 1);
    FreeComplexArray(Delta2, Nh + 1, Nh + 1);


    return Intensity;
}
