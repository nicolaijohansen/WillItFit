int GridsearchLM(struct Dataset * Data, int NumberOfSpectra, struct Parameter * Parameters, int NumberOfParameters, int MaxIterations, double *ChiXX, int NumberOfSmearingFolds,
                 double * VolumesOfMolecules, int NumberOfCyclesInGridsearch, struct Protein ProteinStructure, struct UserDefined * UserDefinedStructure,
                 double DeltaForDifferentiations, bool Printout, int NumberOfSampleInformations, int TotalNumberOfDatapoints, int NumberOfFreeParameters,
                 int HighestNumberOfDatapoints)
{
    // Variables used in iterations
    int i;
    int j;
    int NumberOfCycles;
    int NumberOfParametersToFit;
    double ChiXXDummy = 0.0;
    double BestChisquare = 1e40;
    double PreviousChiXXDummy;
    double StartingValue;

    // Define variables describing fitting parameters
    struct Parameter * DummyParameters;
    AllocateParameters(&DummyParameters, NumberOfParameters);
    int * ParametersToFit;
    Initialize1DIntegerArray(&ParametersToFit, NumberOfParameters);

    // Begin computation
    for(i = 0; i < NumberOfParameters; ++i){
        DummyParameters[i].iParameter = false;
        DummyParameters[i].Value = Parameters[i].Value;
        DummyParameters[i].MinValue = Parameters[i].MinValue;
        DummyParameters[i].MaxValue = Parameters[i].MaxValue;

        if (Printout == true) {
            printf("Parameter %2d = %15g          %s \n", i, Parameters[i].Value, Parameters[i].Name);
        }
    }

    if (Printout == true) {
        printf("\n");
    }

    NumberOfCycles = NumberOfCyclesInGridsearch;
    NumberOfParametersToFit = 0;
    BestChisquare = ComputeChiSquare(Data, NumberOfSpectra, TotalNumberOfDatapoints, NumberOfFreeParameters, Parameters, NumberOfParameters, NumberOfSmearingFolds, 
                                     VolumesOfMolecules, ProteinStructure, UserDefinedStructure);

    ChiXXDummy = BestChisquare;

    for (i = 0; i < NumberOfParameters; ++i) {

        if (Parameters[i].iParameter == true) {
            ParametersToFit[NumberOfParametersToFit] = i;

            ++NumberOfParametersToFit;
        }
    }

    if (Printout == true) {
        ClearScreen();
    }

    // Begin iterating
    for (i = 0; i < NumberOfCycles; ++i) {

        for (j = 0; j < NumberOfParametersToFit; ++j) {
            DummyParameters[ParametersToFit[j]].iParameter = true;
            StartingValue = DummyParameters[ParametersToFit[j]].Value;
            PreviousChiXXDummy = ChiXXDummy;

            LevenbergMarquardt(Data, NumberOfSpectra, DummyParameters, NumberOfParameters, MaxIterations, &ChiXXDummy, NumberOfSmearingFolds, VolumesOfMolecules, true, false,
                               ProteinStructure, &*UserDefinedStructure, DeltaForDifferentiations, NumberOfSampleInformations, TotalNumberOfDatapoints, NumberOfFreeParameters,
                               HighestNumberOfDatapoints);

            DummyParameters[ParametersToFit[j]].iParameter = false;

            if (ChiXXDummy <= BestChisquare) {
                BestChisquare = ChiXXDummy;
                Parameters[ParametersToFit[j]].Error = DummyParameters[ParametersToFit[j]].Error;
                Parameters[ParametersToFit[j]].Value = DummyParameters[ParametersToFit[j]].Value;
            } else {
                DummyParameters[ParametersToFit[j]].Value = StartingValue;
                ChiXXDummy = PreviousChiXXDummy;
            }

            if (Printout == true) {
                printf("Cycle number     = %d \n", i + 1);
                printf("Parameter nr. %2d = %g \n", ParametersToFit[j], DummyParameters[ParametersToFit[j]].Value);
                printf("Chisquare        = %g \n", BestChisquare);
                printf("\n");

                ClearScreen();
            }
        }
    }

    // Conclusion
    *ChiXX = ComputeChiSquare(Data, NumberOfSpectra, TotalNumberOfDatapoints, NumberOfFreeParameters, Parameters, NumberOfParameters, NumberOfSmearingFolds, 
                              VolumesOfMolecules, ProteinStructure, UserDefinedStructure);

    if (Printout == true) {
        printf("\n");
        ClearScreen();
    }

    free(DummyParameters);
    free(ParametersToFit);

    return 0;
}
