double ComputeChiSquare(struct Dataset * Data, int NumberOfSpectra, int TotalNumberOfDatapoints, int NumberOfFreeParameters, struct Parameter * Parameters, 
                       int NumberOfParameters, int NumberOfSmearingFolds, double * VolumesOfMolecules, struct Protein ProteinStructure, struct UserDefined * UserDefinedStructure) 
{
    // Declarations
    int i;
	int j;
	int k;
    double DifferenceInIntensity;
    double DummyParameters[NumberOfParameters];
    double Intensity;
    double Stepsize;
    double SigmaOfQ;
	double Chisquare = 0.0;
    double DummyQ;
    double q;

    // Parameters as list
    for (i = 0; i < NumberOfParameters; ++i) {
        DummyParameters[i] = Parameters[i].Value;
    }

	// Computation
    for (i = 0; i < NumberOfSpectra; ++i) {
		ComputeConstraints(DummyParameters, VolumesOfMolecules, Data[i].ScatteringLengths, Data[i].Contrast,
		                   Data[i].Concentration, Data[i].Constraints, ProteinStructure, UserDefinedStructure);

        #pragma omp parallel for schedule(dynamic) default(shared) private(q, j, k, Intensity, DummyQ, SigmaOfQ, Stepsize, DifferenceInIntensity)
        for (j = Data[i].NMin; j < Data[i].NMax; ++j) {
			q = Data[i].QValues[j];

			if (Data[i].IncludeResolutionEffects == true) {
				Intensity = 0.0;
				SigmaOfQ  = Data[i].SigmaQValues[j];
				Stepsize  = 6.0 * SigmaOfQ / (1.0 * NumberOfSmearingFolds);

				for (k = 0; k < NumberOfSmearingFolds; ++k) {
				    DummyQ = q + (k + 0.5 - NumberOfSmearingFolds / 2.0) * Stepsize;

				    if (DummyQ < 1e-9) {
				        DummyQ = 1e-9;
				    }

				    Intensity += Model(DummyQ, DummyParameters, Data[i].Constraints, Data[i].Contrast, ProteinStructure, UserDefinedStructure) *
				                       Data[i].ResolutionWeights[j][k];
				}
			} else {
				Intensity = Model(q, DummyParameters, Data[i].Constraints, Data[i].Contrast, ProteinStructure, UserDefinedStructure);
			}

			// Calculate chisquare
			Data[i].FitValues[j]  = Intensity;
			DifferenceInIntensity = Data[i].IValues[j] - Intensity;

			#pragma omp atomic
			Chisquare += DifferenceInIntensity * DifferenceInIntensity * Data[i].SigmaValues[j];
		}
	}

	// Normalize and return
	Chisquare /= 1.0 * (TotalNumberOfDatapoints - NumberOfFreeParameters);

    return Chisquare;
}

void ComputeTheGradient(struct Dataset * Data, int NumberOfSpectra, int TotalNumberOfDatapoints, int NumberOfFreeParameters, struct Parameter * Parameters, 
                        int NumberOfParameters, int NumberOfSmearingFolds, double * VolumesOfMolecules, struct Protein ProteinStructure, 
                        struct UserDefined * UserDefinedStructure, double DeltaForDifferentiations, double ** AlphaMatrix, double * Beta)
{
    // Declarations
    int i;
    int j;
	int k;
	int l;
	double q;
    double DummyQ;
    double dParameter;
	double Intensity;
    double DummyIntensity;
	double DifferenceInIntensity;
    double Stepsize;
    double OriginalParameterValue;
    double SigmaOfQ;
    double DummyParameters[NumberOfParameters];

    // Parameters as list
    for (i = 0; i < NumberOfParameters; ++i) {
        DummyParameters[i] = Parameters[i].Value;
    }

	// Computation
    for (i = 0; i < NumberOfParameters; ++i) {

        if (Parameters[i].iParameter == true) {
            dParameter = DeltaForDifferentiations * DummyParameters[i];
            OriginalParameterValue = DummyParameters[i];

            if (dParameter < 1e-5) {
                dParameter = 1e-5;
            }

            DummyParameters[i] += dParameter;

			// Loop over all data points
		    for (j = 0; j < NumberOfSpectra; ++j) {
		        ComputeConstraints(DummyParameters, VolumesOfMolecules, Data[j].ScatteringLengths, Data[j].Contrast,
		                           Data[j].Concentration, Data[j].Constraints, ProteinStructure, UserDefinedStructure);

				#pragma omp parallel for schedule(dynamic) default(shared) private(q, k, l, Intensity, DummyIntensity, DummyQ, SigmaOfQ, Stepsize, DifferenceInIntensity)
	    	    for (k = Data[j].NMin; k < Data[j].NMax; ++k) {
					q                     = Data[j].QValues[k];
					Intensity             = Data[j].FitValues[k];
					DifferenceInIntensity = Data[j].IValues[k] - Intensity;

					if (Data[j].IncludeResolutionEffects == true) {
						DummyIntensity = 0.0;
						SigmaOfQ       = Data[j].SigmaQValues[k];
						Stepsize       = 6.0 * SigmaOfQ / (1.0 * NumberOfSmearingFolds);

						for (l = 0; l < NumberOfSmearingFolds; ++l) {
							DummyQ = q + (l + 0.5 - NumberOfSmearingFolds / 2.0) * Stepsize;

							if (DummyQ < 1e-9) {
								DummyQ = 1e-9;
							}

							DummyIntensity += Model(DummyQ, DummyParameters, Data[j].Constraints, Data[j].Contrast, ProteinStructure, UserDefinedStructure) *
								              Data[j].ResolutionWeights[k][l];
						}
					} else {
						DummyIntensity = Model(q, DummyParameters, Data[j].Constraints, Data[j].Contrast, ProteinStructure, UserDefinedStructure);
					}

					// Calculate gradient
			        Data[j].Gradient[k][i] = (Intensity - DummyIntensity) / dParameter;

					// Construct beta
					#pragma omp atomic
					Beta[i] += DifferenceInIntensity * Data[j].SigmaValues[k] * Data[j].Gradient[k][i];
				}
			}

        	DummyParameters[i] = OriginalParameterValue;
	    }
    }

	// Construct alpha matrix
    for (i = 0; i < NumberOfSpectra; ++i) {

   	    for (j = Data[i].NMin; j < Data[i].NMax; ++j) {

			for (k = 0; k < NumberOfParameters; ++k) {

		        if (Parameters[k].iParameter == true) {

					for (l = 0; l < NumberOfParameters; ++l) {

					    if (Parameters[l].iParameter == true) {
							AlphaMatrix[k][l] += Data[i].SigmaValues[j] * Data[i].Gradient[j][k] * Data[i].Gradient[j][l];
						}
					}
				}
			}
		}
    }

	// Normalize alpha and beta
	for (i = 0; i < NumberOfParameters; ++i) {
		Beta[i] /= 1.0 * (TotalNumberOfDatapoints - NumberOfFreeParameters);

		for (j = 0; j < NumberOfParameters; ++j) {
			AlphaMatrix[i][j] /= 1.0 * (TotalNumberOfDatapoints - NumberOfFreeParameters);
		}
	}

	return;
}

void ComputeValueAndCovarianceMatrix(struct Dataset * Data, int NumberOfSpectra, struct Parameter * Parameters, int NumberOfParameters, int NumberOfSmearingFolds,
                                     double * VolumesOfMolecules, struct Protein ProteinStructure, struct UserDefined * UserDefinedStructure, double ** AlphaMatrix,
                                     double * Beta, double *ChisquareFinal, double DeltaForDifferentiations, int NumberOfSampleInformations, int TotalNumberOfDatapoints,
                                     int NumberOfFreeParameters, int HighestNumberOfDatapoints)
{
	// Declarations
	int i;
	int j;
	double Chisquare;

    // Initialisation
    for (i = 0; i < NumberOfParameters; ++i) {

		for (j = 0; j < NumberOfParameters; ++j) {

            if (i == j && Parameters[i].iParameter == false) {
                AlphaMatrix[i][j] = 1.0;
            } else {
                AlphaMatrix[i][j] = 0.0;
            }
        }

		Beta[i] = 0.0;
	}

	// Computation
    Chisquare = ComputeChiSquare(Data, NumberOfSpectra, TotalNumberOfDatapoints, NumberOfFreeParameters, Parameters, NumberOfParameters, NumberOfSmearingFolds, VolumesOfMolecules, 
                                 ProteinStructure, UserDefinedStructure);

    ComputeTheGradient(Data, NumberOfSpectra, TotalNumberOfDatapoints, NumberOfFreeParameters, Parameters, NumberOfParameters, NumberOfSmearingFolds, VolumesOfMolecules, 
                       ProteinStructure, UserDefinedStructure, DeltaForDifferentiations, AlphaMatrix, Beta);

	// Return
    *ChisquareFinal = Chisquare;

	return;
}

int GaussJordanElimination(double ** Matrix, int SizeOfMatrix, double * Vector)
{
    // Define macro used to swap to elements
    double Temp;
    #define SWAP(a, b) {Temp = (a); (a) = (b); (b) = Temp;}

    // Integers used for iteration
    int i;
    int j;
    int k;

    // Dummy variables
    double BigDummy;
    double Dummy;

    double InversePivot;
    int Pivot[SizeOfMatrix];

    // Locations in the matrix
    int Column = 0;
    int Row = 0;

    int ColumnIndex[SizeOfMatrix];
    int RowIndex[SizeOfMatrix];

    // Function Body
    for (i = 0; i < SizeOfMatrix; ++i) {
        Pivot[i] = 0;
    }

    for (i = 0; i < SizeOfMatrix; ++i) {
        BigDummy = 0.0;

        // Search for largest element in matrix
        for (j = 0; j < SizeOfMatrix; ++j) {

            if (Pivot[j] != 1) {

                for (k = 0; k < SizeOfMatrix; ++k) {

                    if (Pivot[k] == 0) {

                        if (fabs(Matrix[j][k]) >= BigDummy) {
                            BigDummy = fabs(Matrix[j][k]);
                            Row = j;
                            Column = k;
                        }

                    // Test for singularity
                    } else if (Pivot[k] > 1) {
                        return -1;
                    }
                }
            }
        }

        ++Pivot[Column];

        // Put largest element in diagonal
        if (Row != Column) {

            for (j = 0; j < SizeOfMatrix; ++j) {
                SWAP(Matrix[Row][j], Matrix[Column][j]);
            }

            SWAP(Vector[Row], Vector[Column]);
        }

        RowIndex[i] = Row;
        ColumnIndex[i] = Column;

        // Test for singularity
        if (Matrix[Column][Column] == 0.0){
            return -1;
        }

        // Invert the pivot and divide the column and the vector element by it
        InversePivot = 1.0 / Matrix[Column][Column];
        Matrix[Column][Column] = 1.0;

        for (j = 0; j < SizeOfMatrix; ++j) {
            Matrix[Column][j] *= InversePivot;
        }

        Vector[Column] *= InversePivot;

        // Reduce the rest of the matrix
        for (j = 0; j < SizeOfMatrix; ++j) {

            if (j != Column) {
                Dummy = Matrix[j][Column];
                Matrix[j][Column] = 0.0;

                for (k = 0; k < SizeOfMatrix; ++k) {
                    Matrix[j][k] -= Matrix[Column][k] * Dummy;
                }

                Vector[j] -= Vector[Column] * Dummy;
            }
        }
    }

    // Reconstruct matrix to original order
    for (i = SizeOfMatrix - 1; i >= 0; --i) {

        if (RowIndex[i] != ColumnIndex[i]) {

            for (j = 0; j < SizeOfMatrix; ++j) {
                SWAP(Matrix[j][RowIndex[i]], Matrix[j][ColumnIndex[i]]);
            }
        }
    }

    return 0;
}

void RunLevenbergMarquardt(struct Dataset * Data, int NumberOfSpectra, struct Parameter * Parameters, int NumberOfParameters, int NumberOfSmearingFolds, double * VolumesOfMolecules,
                           struct Protein ProteinStructure, struct UserDefined * UserDefinedStructure,  double DeltaForDifferentiations, double ** CovarianceMatrix,
                           double ** AlphaMatrix, double * Lambda, double *Chisquare, double * Beta, int NumberOfSampleInformations, int TotalNumberOfDatapoints,
                           int NumberOfFreeParameters, int HighestNumberOfDatapoints)
{
    // Declarations
    int i;
    int j;

    int GaussError;
	struct Parameter * DummyParameters;
	static double * ParameterSteps;
	static double * ParameterStepsDummy;
	static double PreviousChisquare;

	// Initialize
    AllocateParameters(&DummyParameters, NumberOfParameters);
    Initialize1DArray(&ParameterSteps, NumberOfParameters);
    Initialize1DArray(&ParameterStepsDummy, NumberOfParameters);

    for (i = 0; i < NumberOfParameters; ++i) {
        DummyParameters[i].iParameter = Parameters[i].iParameter;
    }

	if (*Lambda < 0.0) {
		*Lambda = 0.001;

		ComputeValueAndCovarianceMatrix(Data, NumberOfSpectra, Parameters, NumberOfParameters, NumberOfSmearingFolds, VolumesOfMolecules, ProteinStructure, &*UserDefinedStructure,
                                        AlphaMatrix, Beta, &*Chisquare, DeltaForDifferentiations, NumberOfSampleInformations, TotalNumberOfDatapoints, NumberOfFreeParameters,
                                        HighestNumberOfDatapoints);

		PreviousChisquare = *Chisquare;
	}

    // Prepare CovarianceMatrix matrix
	for (i = 0; i < NumberOfParameters; ++i) {

		for (j = 0; j < NumberOfParameters; ++j) {
            CovarianceMatrix[i][j] = AlphaMatrix[i][j];
        }

		if (Parameters[i].iParameter == true) {
            CovarianceMatrix[i][i] = AlphaMatrix[i][i] * (1.0 + (*Lambda));
        }

		ParameterStepsDummy[i] = Beta[i];
	}

    // Solve the matrix problem
	GaussError = GaussJordanElimination(CovarianceMatrix, NumberOfParameters, ParameterStepsDummy);

	if (GaussError < 0) {
        printf("  ***************************************************************************\n");
        printf("  * Singularity in covariance matrix - unable to invert...                  *\n");
        printf("  * Perhaps the algorithm is trying to refine a parameter with no impact... *\n");
        printf("  ***************************************************************************\n\n");

        free(ParameterStepsDummy);
		free(ParameterSteps);
		free(DummyParameters);

		return;
	}

    // Use the derived stepsizes
    if (*Lambda == 0.0) {
		free(ParameterStepsDummy);
		free(ParameterSteps);
		free(DummyParameters);

		return;
	}

	for (i = 0; i < NumberOfParameters; ++i) {
        ParameterSteps[i] = ParameterStepsDummy[i];
    }

    // Compute new parameter values
	for (i = 0; i < NumberOfParameters; ++i) {
        DummyParameters[i].Value = Parameters[i].Value - ParameterSteps[i];

        if (Parameters[i].iParameter == true) {

            if (DummyParameters[i].Value > Parameters[i].MaxValue) {
                DummyParameters[i].Value = Parameters[i].MaxValue;
            }

            if (DummyParameters[i].Value < Parameters[i].MinValue) {
                DummyParameters[i].Value = Parameters[i].MinValue;
            }
        }
    }

    ComputeValueAndCovarianceMatrix(Data, NumberOfSpectra, DummyParameters, NumberOfParameters, NumberOfSmearingFolds, VolumesOfMolecules, ProteinStructure, &*UserDefinedStructure,
                                    CovarianceMatrix, ParameterSteps, &*Chisquare, DeltaForDifferentiations, NumberOfSampleInformations, TotalNumberOfDatapoints, NumberOfFreeParameters,
                                    HighestNumberOfDatapoints);

	if (*Chisquare < PreviousChisquare) {
		*Lambda *= 0.1;
		PreviousChisquare = *Chisquare;

		for (i = 0; i < NumberOfParameters; ++i) {

			for (j = 0; j < NumberOfParameters; ++j) {
                AlphaMatrix[i][j] = CovarianceMatrix[i][j];
            }

			Beta[i] = ParameterSteps[i];
		}

		for (i = 0; i < NumberOfParameters; ++i) {
            Parameters[i].Value = DummyParameters[i].Value;
        }
	} else {
		*Lambda *= 10.0;
		*Chisquare = PreviousChisquare;
	}

    free(ParameterStepsDummy);
    free(ParameterSteps);
    free(DummyParameters);

	return;
}

void PrintCovarianceMatrixFnc(int NumberOfParameters, double ** CovarianceMatrix)
{
    // Declarations
    int i;
    int j;

    FILE *Outputfile;

    // Print-out
    Outputfile = fopen(".data/CovarianceMatrix.dat", "w+");

    fprintf(Outputfile, "Covariance matrix: \n");

    fprintf(Outputfile, "      ");

    for (i = 0; i < NumberOfParameters; ++i) {
        fprintf(Outputfile, "%10d:  ", i);
    }

    fprintf(Outputfile, "\n");

    for (i = 0; i < NumberOfParameters; ++i) {
        fprintf(Outputfile, "%2d:  ", i);

        for (j = 0; j < NumberOfParameters; ++j) {
            fprintf(Outputfile, "%12g ", CovarianceMatrix[j][i]);
        }

        fprintf(Outputfile, "\n");
    }

    fclose(Outputfile);
}
