/***************************************************
 *
 * Model name: [The name of the model goes here]
 * Author    : [Your name goes here]
 * Email     : [Your email goes here]
 *
 ***************************************************/

// List of headers to be included on compilation
#include "HeaderWithHelperFunctions.h"
#include "ExampleModel.h"

/***************************************************
 * 
 * In these header file, the following functions
 * must be present:
 *  - ComputeConstraints
 *  - Model
 *  - OutputData
 * 
 * using the syntax outlined in this example.
 * 
 ***************************************************/
