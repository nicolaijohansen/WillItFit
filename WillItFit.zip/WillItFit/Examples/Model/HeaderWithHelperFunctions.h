// You can include any number of helper functions in your model. No particular syntax is required here.

double HelperFunction(AnySyntaxGoesHere)
{
    /*
     * 
     * 
     * 
     */
}
